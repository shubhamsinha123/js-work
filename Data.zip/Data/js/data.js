showmore.addEventListener('click', () => {

    if (x < arr.length) {
      // if(arr[])
      arr[x].style.display = "block"
      arr[++x].style.display = "block"
      arr[++x].style.display = "block"
      ++x;
      if (x == arr.length) {
        showmore.innerHTML = "Show Less";
        x++;
      }
    }
    else {
      x--;
      arr[--x].style.display = "none"
      arr[--x].style.display = "none"
      arr[--x].style.display = "none"
      // --x;
      // showless.id = "showmore";
      showmore.innerHTML = "Show More";
    }
  
  
  
    
  
  
  });
  